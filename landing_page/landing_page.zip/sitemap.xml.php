<?php
header('Content-Type: application/xml; charset=utf-8');
$version = '1.0';
$encoding = 'UTF-8';
echo '<?xml version="' . $version . '" encoding="' . $encoding . '"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
   <url>
      <loc>https://tiktok.crty-dev.com/</loc>
      <lastmod><?php echo date('Y-m-d'); ?></lastmod>
      <changefreq>weekly</changefreq>
      <priority>1.0</priority>
   </url>
</urlset>
