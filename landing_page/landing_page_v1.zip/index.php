<?php
// --- CONFIGURATION ---
$app_name = "TikTok Pro";
$app_version = "v1.0.0";
$author = "CRTY_LABS";
$description = "The ultimate power-user suite for TikTok. Stealth mode, HD archiving, and real-time performance tracking.";

// Download Handler
if (isset($_GET['access'])) {
    $token = $_GET['access'];
    $file = '';
    
    if ($token === 'win_x64_exe') { $file = 'download/TikTok_Pro_v1.0.0_x64-setup.exe'; $filename = 'TikTok_Pro_v1.0.0.exe'; }
    else if ($token === 'win_x64_msi') { $file = 'download/TikTok_Pro_v1.0.0_x64_en-US.msi'; $filename = 'TikTok_Pro_v1.0.0.msi'; }
    else if ($token === 'mac_universal_dmg') { $file = 'download/TikTok_Pro_v1.0.0.dmg'; $filename = 'TikTok_Pro_v1.0.0.dmg'; }

    if ($file && file_exists($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $app_name; ?> Studio | Elite Desktop Experience</title>
    <meta name="description" content="<?php echo $description; ?>">
    <link rel="stylesheet" href="assets/css/styles.css">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>
    <!-- Background Layer -->
    <div class="cyber-grid"></div>
    <div class="orb orb-primary"></div>
    <div class="orb orb-secondary"></div>

    <header>
        <div class="container" style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
            <div class="brand" style="display: flex; align-items: center; gap: 12px; font-weight: 900; font-size: 1.5rem; letter-spacing: -1px;">
                <img src="assets/icons/logo.svg" alt="<?php echo $app_name; ?> Logo" width="32" height="32">
                <?php echo strtoupper($app_name); ?>
            </div>
            <nav style="display: flex; gap: 2rem;">
                <a href="#features" style="color: var(--text-dim); text-decoration: none; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Features</a>
                <a href="#download" style="color: var(--text-dim); text-decoration: none; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Download</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <div class="hero-content">
                    <span class="badge fade-up"><?php echo $app_version; ?> STABLE RELEASE</span>
                    <h1 class="fade-up">RETYPE THE<br>FLOW.</h1>
                    <p class="hero-desc fade-up"><?php echo $description; ?></p>
                    
                    <div class="btn-group fade-up" id="download">
                        <a href="?access=win_x64_exe" class="btn btn-primary">
                            <i data-lucide="download"></i>
                            WINDOWS RELEASE
                        </a>
                        <a href="?access=mac_universal_dmg" class="btn btn-glass">
                            <i data-lucide="apple"></i>
                            MACOS BUILD
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <section class="features" id="features">
            <div class="container">
                <div class="grid">
                    <div class="feature-card fade-up">
                        <div class="icon-box">
                            <i data-lucide="shield"></i>
                        </div>
                        <h3>Stealth Mode</h3>
                        <p>Ghost-protocol browsing. Bypass region locks and algorithmic tracking with an integrated proxy layer.</p>
                    </div>

                    <div class="feature-card fade-up">
                        <div class="icon-box">
                            <i data-lucide="database"></i>
                        </div>
                        <h3>Media Vault</h3>
                        <p>Zero-loss binary capture. Archive high-fidelity videos directly to your local filesystem with metadata preservation.</p>
                    </div>

                    <div class="feature-card fade-up">
                        <div class="icon-box">
                            <i data-lucide="terminal"></i>
                        </div>
                        <h3>Dev HUD</h3>
                        <p>Experimental system diagnostics. Real-time resource monitoring and network telemetry for the curious mind.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p class="footer-text">DESIGNED BY <?php echo $author; ?> // SYSTEM_ID: <?php echo str_replace(' ', '_', strtoupper($app_name)); ?>_CORE</p>
        </div>
    </footer>

    <script src="assets/js/scripts.js"></script>
    <script>
        // Init Lucide
        lucide.createIcons();
    </script>
</body>
</html>
